import React from 'react';
import { Tab } from './Tab';
import { Logo } from './Logo';
import { TabData } from '../types/browser';

interface TabBarProps {
  tabs: TabData[];
  activeTab: number;
  onTabClose: (id: number) => void;
  onTabSelect: (id: number) => void;
}

export function TabBar({ tabs, activeTab, onTabClose, onTabSelect }: TabBarProps) {
  return (
    <div className="bg-gray-100 px-2 pt-2 flex items-center gap-2">
      <Logo />
      <div className="flex gap-1 flex-1">
        {tabs.map(tab => (
          <Tab
            key={tab.id}
            title={tab.title}
            active={tab.id === activeTab}
            onClose={() => onTabClose(tab.id)}
            onClick={() => onTabSelect(tab.id)}
          />
        ))}
      </div>
    </div>
  );
}