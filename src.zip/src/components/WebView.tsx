import React from 'react';

interface WebViewProps {
  url: string;
}

export function WebView({ url }: WebViewProps) {
  return (
    <iframe
      src={url}
      className="w-full h-full border-none"
      sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
      title="web-content"
    />
  );
}