import React from 'react';
import { Carrot } from 'lucide-react';

export function Footer() {
  return (
    <div className="flex flex-col items-center gap-4 text-gray-500">
      <Carrot className="h-24 w-24 text-orange-500" />
      <div className="text-center">
        <p className="text-lg mb-2">Welcome to Carrot Browser</p>
        <p className="text-sm">by Carrot Studio, Badr Team</p>
      </div>
    </div>
  );
}