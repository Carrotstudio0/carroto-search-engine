import React from 'react';
import { Carrot } from 'lucide-react';

interface SearchAnimationProps {
  isVisible: boolean;
}

export function SearchAnimation({ isVisible }: SearchAnimationProps) {
  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-white bg-opacity-90 flex items-center justify-center z-50">
      <div className="relative">
        {/* Main spinning carrot */}
        <Carrot className="h-16 w-16 text-orange-500 animate-spin" />
        
        {/* Floating carrots */}
        <div className="absolute top-0 left-0 -translate-x-full animate-float-1">
          <Carrot className="h-8 w-8 text-orange-400" />
        </div>
        <div className="absolute top-0 right-0 translate-x-full animate-float-2">
          <Carrot className="h-6 w-6 text-orange-300" />
        </div>
        <div className="absolute bottom-0 left-0 -translate-x-full animate-float-3">
          <Carrot className="h-10 w-10 text-orange-400" />
        </div>
        <div className="absolute bottom-0 right-0 translate-x-full animate-float-4">
          <Carrot className="h-12 w-12 text-orange-300" />
        </div>
      </div>
    </div>
  );
}