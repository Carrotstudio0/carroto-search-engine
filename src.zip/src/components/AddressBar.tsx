import React, { useState, useEffect } from 'react';
import { Search } from 'lucide-react';

interface AddressBarProps {
  url: string;
  onNavigate: (url: string) => void;
}

export function AddressBar({ url, onNavigate }: AddressBarProps) {
  const [inputValue, setInputValue] = useState(url);

  useEffect(() => {
    setInputValue(url);
  }, [url]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNavigate(inputValue);
  };

  return (
    <form onSubmit={handleSubmit} className="flex-1 flex items-center px-2">
      <div className="relative w-full">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Search Google or enter address"
          className="w-full py-1.5 pl-10 pr-4 rounded-full bg-gray-100 focus:bg-white border border-transparent focus:border-gray-300 outline-none transition-colors"
        />
      </div>
    </form>
  );
}