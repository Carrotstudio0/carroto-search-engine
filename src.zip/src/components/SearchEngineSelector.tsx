import React from 'react';
import { SearchEngine } from '../types/search';
import { SearchEngineIcon } from './SearchEngineIcon';
import { useShortcuts } from '../hooks/useShortcuts';

interface SearchEngineSelectorProps {
  value: SearchEngine;
  onChange: (engine: SearchEngine) => void;
}

export function SearchEngineSelector({ value, onChange }: SearchEngineSelectorProps) {
  useShortcuts({
    'Alt+g': () => onChange(SearchEngine.Google),
    'Alt+b': () => onChange(SearchEngine.Bing),
    'Alt+d': () => onChange(SearchEngine.DuckDuckGo),
  });

  return (
    <div className="flex items-center gap-2">
      {Object.values(SearchEngine).map((engine) => (
        <button
          key={engine}
          onClick={() => onChange(engine)}
          className={`p-2 rounded-full transition-colors flex items-center justify-center ${
            value === engine
              ? 'bg-orange-500 text-white'
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
          title={`Search with ${engine} (Alt+${engine.charAt(0).toLowerCase()})`}
        >
          <SearchEngineIcon engine={engine} size={20} />
        </button>
      ))}
    </div>
  );
}