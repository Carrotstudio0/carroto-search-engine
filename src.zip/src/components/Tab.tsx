import React from 'react';
import { X } from 'lucide-react';

interface TabProps {
  title: string;
  active?: boolean;
  onClose: () => void;
  onClick: () => void;
}

export function Tab({ title, active, onClose, onClick }: TabProps) {
  return (
    <div
      onClick={onClick}
      className={`group flex items-center gap-2 px-4 py-2 rounded-t-lg cursor-pointer ${
        active
          ? 'bg-white text-gray-800'
          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
      }`}
    >
      <span className="truncate max-w-[140px]">{title}</span>
      <button
        onClick={(e) => {
          e.stopPropagation();
          onClose();
        }}
        className="opacity-0 group-hover:opacity-100 hover:bg-gray-200 p-0.5 rounded"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}