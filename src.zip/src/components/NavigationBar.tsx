import React from 'react';
import { ChevronLeft, ChevronRight, RotateCcw, Plus } from 'lucide-react';
import { AddressBar } from './AddressBar';
import { DownloadButton } from './DownloadButton';

interface NavigationBarProps {
  onNewTab: () => void;
  url: string;
  onNavigate: (url: string) => void;
  onBack?: () => void;
  onForward?: () => void;
  onReload?: () => void;
  canGoBack?: boolean;
  canGoForward?: boolean;
}

export function NavigationBar({ 
  onNewTab, 
  url, 
  onNavigate,
  onBack,
  onForward,
  onReload,
  canGoBack = false,
  canGoForward = false
}: NavigationBarProps) {
  return (
    <div className="flex items-center gap-2 p-2 bg-white border-b">
      <button 
        className={`p-1.5 rounded-full ${canGoBack ? 'hover:bg-gray-100 text-gray-600' : 'text-gray-300'}`}
        onClick={onBack}
        disabled={!canGoBack}
      >
        <ChevronLeft className="h-5 w-5" />
      </button>
      <button 
        className={`p-1.5 rounded-full ${canGoForward ? 'hover:bg-gray-100 text-gray-600' : 'text-gray-300'}`}
        onClick={onForward}
        disabled={!canGoForward}
      >
        <ChevronRight className="h-5 w-5" />
      </button>
      <button 
        className="p-1.5 rounded-full hover:bg-gray-100"
        onClick={onReload}
      >
        <RotateCcw className="h-5 w-5 text-gray-600" />
      </button>
      <AddressBar url={url} onNavigate={onNavigate} />
      <DownloadButton url={url} />
      <button
        onClick={onNewTab}
        className="p-1.5 rounded-full hover:bg-gray-100"
      >
        <Plus className="h-5 w-5 text-gray-600" />
      </button>
    </div>
  );
}