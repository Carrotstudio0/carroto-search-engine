import React from 'react';
import { Carrot } from 'lucide-react';

export function Logo() {
  return (
    <Carrot className="h-6 w-6 text-orange-500" />
  );
}