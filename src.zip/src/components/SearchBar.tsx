import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { SearchEngineSelector } from './SearchEngineSelector';
import { SearchEngineIcon } from './SearchEngineIcon';
import { useSearch } from '../hooks/useSearch';
import { useShortcuts } from '../hooks/useShortcuts';

interface SearchBarProps {
  onSearch: (url: string) => void;
}

export function SearchBar({ onSearch }: SearchBarProps) {
  const [query, setQuery] = useState('');
  const { searchEngine, setSearchEngine, getSearchUrl } = useSearch();
  const inputRef = React.useRef<HTMLInputElement>(null);

  useShortcuts({
    'Alt+s': () => inputRef.current?.focus(),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    
    const searchUrl = getSearchUrl(query);
    onSearch(searchUrl);
    setQuery('');
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4">
      <form onSubmit={handleSubmit} className="max-w-3xl mx-auto flex gap-2">
        <SearchEngineSelector
          value={searchEngine}
          onChange={setSearchEngine}
        />
        <div className="flex-1 relative">
          <div className="absolute left-3 top-1/2 -translate-y-1/2">
            <SearchEngineIcon engine={searchEngine} size={20} />
          </div>
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={`Search with ${searchEngine} (Alt+S to focus)`}
            className="w-full pl-10 pr-4 py-2 rounded-full border border-gray-300 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none"
          />
        </div>
        <button
          type="submit"
          className="px-6 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-full font-medium transition-colors"
        >
          Search
        </button>
      </form>
    </div>
  );
}