import React from 'react';
import { SearchEngine } from '../types/search';

interface SearchEngineIconProps {
  engine: SearchEngine;
  size?: number;
}

export function SearchEngineIcon({ engine, size = 24 }: SearchEngineIconProps) {
  const icons = {
    [SearchEngine.Google]: 'https://www.google.com/favicon.ico',
    [SearchEngine.Bing]: 'https://www.bing.com/favicon.ico',
    [SearchEngine.DuckDuckGo]: 'https://duckduckgo.com/favicon.ico'
  };

  return (
    <img
      src={icons[engine]}
      alt={`${engine} icon`}
      width={size}
      height={size}
      className="rounded-sm"
    />
  );
}