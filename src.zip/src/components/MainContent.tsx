import React from 'react';
import { Footer } from './Footer';
import { WebView } from './WebView';
import { TabData } from '../types/browser';

interface MainContentProps {
  tab?: TabData;
}

export function MainContent({ tab }: MainContentProps) {
  return (
    <div className="flex-1 bg-white">
      {tab?.url === 'about:blank' ? (
        <div className="h-full flex items-center justify-center">
          <Footer />
        </div>
      ) : (
        <WebView url={tab?.url || ''} />
      )}
    </div>
  );
}