import React from 'react';
import { Download } from 'lucide-react';
import { useDownload } from '../hooks/useDownload';

interface DownloadButtonProps {
  url: string;
}

export function DownloadButton({ url }: DownloadButtonProps) {
  const { startDownload, isDownloading } = useDownload();

  return (
    <button
      onClick={() => startDownload(url)}
      disabled={isDownloading}
      className={`p-1.5 rounded-full hover:bg-gray-100 ${
        isDownloading ? 'text-gray-400' : 'text-gray-600'
      }`}
      title="Download"
    >
      <Download className={`h-5 w-5 ${isDownloading ? 'animate-bounce' : ''}`} />
    </button>
  );
}