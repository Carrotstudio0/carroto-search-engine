import { useState } from 'react';

export function useDownload() {
  const [isDownloading, setIsDownloading] = useState(false);

  const startDownload = async (url: string) => {
    if (!url || url === 'about:blank') return;
    
    try {
      setIsDownloading(true);
      
      // Create a temporary anchor element
      const link = document.createElement('a');
      link.href = url;
      
      // Extract filename from URL or use default
      const filename = url.split('/').pop() || 'download';
      link.download = filename;
      
      // Trigger download
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
    } catch (error) {
      console.error('Download failed:', error);
    } finally {
      // Add a small delay to show the animation
      setTimeout(() => setIsDownloading(false), 1000);
    }
  };

  return { startDownload, isDownloading };
}