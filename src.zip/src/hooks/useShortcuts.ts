import { useEffect } from 'react';

type ShortcutMap = {
  [key: string]: () => void;
};

export function useShortcuts(shortcuts: ShortcutMap) {
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      const key = event.altKey
        ? `Alt+${event.key.toLowerCase()}`
        : event.key.toLowerCase();

      const action = shortcuts[key];
      if (action) {
        event.preventDefault();
        action();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [shortcuts]);
}