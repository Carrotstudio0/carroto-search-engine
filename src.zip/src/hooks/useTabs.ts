import { useState } from 'react';
import { TabData } from '../types/browser';

export function useTabs() {
  const [tabs, setTabs] = useState<TabData[]>([
    { id: 1, title: 'New Tab', url: 'about:blank', history: [], currentIndex: -1 }
  ]);
  const [activeTab, setActiveTab] = useState(1);
  const [isLoading, setIsLoading] = useState(false);

  const addTab = () => {
    const newTab = {
      id: Date.now(),
      title: 'New Tab',
      url: 'about:blank',
      history: [],
      currentIndex: -1
    };
    setTabs([...tabs, newTab]);
    setActiveTab(newTab.id);
  };

  const closeTab = (id: number) => {
    if (tabs.length === 1) return;
    const newTabs = tabs.filter(tab => tab.id !== id);
    setTabs(newTabs);
    if (activeTab === id) {
      setActiveTab(newTabs[newTabs.length - 1].id);
    }
  };

  const updateTab = (id: number, updates: Partial<TabData>) => {
    setTabs(tabs.map(tab => 
      tab.id === id ? { ...tab, ...updates } : tab
    ));
  };

  const navigateTab = async (id: number, url: string, addToHistory = true) => {
    setIsLoading(true);
    
    const isUrl = /^https?:\/\//.test(url) || /^[\w-]+\.[a-z]{2,}/.test(url);
    const finalUrl = isUrl 
      ? (url.startsWith('http') ? url : `https://${url}`)
      : `https://www.google.com/search?q=${encodeURIComponent(url)}`;
    
    const tab = tabs.find(t => t.id === id);
    if (tab && addToHistory) {
      const newHistory = tab.history.slice(0, tab.currentIndex + 1);
      newHistory.push(finalUrl);
      updateTab(id, {
        url: finalUrl,
        title: url,
        history: newHistory,
        currentIndex: newHistory.length - 1
      });
    } else {
      updateTab(id, { url: finalUrl, title: url });
    }
    
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsLoading(false);
  };

  const goBack = (id: number) => {
    const tab = tabs.find(t => t.id === id);
    if (tab && tab.currentIndex > 0) {
      const newIndex = tab.currentIndex - 1;
      const previousUrl = tab.history[newIndex];
      updateTab(id, { currentIndex: newIndex });
      navigateTab(id, previousUrl, false);
    }
  };

  const goForward = (id: number) => {
    const tab = tabs.find(t => t.id === id);
    if (tab && tab.currentIndex < tab.history.length - 1) {
      const newIndex = tab.currentIndex + 1;
      const nextUrl = tab.history[newIndex];
      updateTab(id, { currentIndex: newIndex });
      navigateTab(id, nextUrl, false);
    }
  };

  const reload = (id: number) => {
    const tab = tabs.find(t => t.id === id);
    if (tab && tab.url !== 'about:blank') {
      navigateTab(id, tab.url, false);
    }
  };

  const canGoBack = (id: number) => {
    const tab = tabs.find(t => t.id === id);
    return tab ? tab.currentIndex > 0 : false;
  };

  const canGoForward = (id: number) => {
    const tab = tabs.find(t => t.id === id);
    return tab ? tab.currentIndex < tab.history.length - 1 : false;
  };

  return {
    tabs,
    activeTab,
    isLoading,
    addTab,
    closeTab,
    setActiveTab,
    navigateTab,
    goBack,
    goForward,
    reload,
    canGoBack,
    canGoForward
  };
}