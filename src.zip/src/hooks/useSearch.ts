import { useState } from 'react';
import { SearchEngine } from '../types/search';

export function useSearch() {
  const [searchEngine, setSearchEngine] = useState<SearchEngine>(SearchEngine.Google);

  const getSearchUrl = (query: string) => {
    const encodedQuery = encodeURIComponent(query);
    
    switch (searchEngine) {
      case SearchEngine.Google:
        return `https://www.google.com/search?q=${encodedQuery}`;
      case SearchEngine.Bing:
        return `https://www.bing.com/search?q=${encodedQuery}`;
      case SearchEngine.DuckDuckGo:
        return `https://duckduckgo.com/?q=${encodedQuery}`;
    }
  };

  return {
    searchEngine,
    setSearchEngine,
    getSearchUrl
  };
}