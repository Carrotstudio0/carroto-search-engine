export enum SearchEngine {
  Google = 'Google',
  Bing = 'Bing',
  DuckDuckGo = 'DuckDuckGo'
}