export interface TabData {
  id: number;
  title: string;
  url: string;
  history: string[];
  currentIndex: number;
}