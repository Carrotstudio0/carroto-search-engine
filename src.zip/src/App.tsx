import React from 'react';
import { NavigationBar } from './components/NavigationBar';
import { TabBar } from './components/TabBar';
import { MainContent } from './components/MainContent';
import { SearchAnimation } from './components/SearchAnimation';
import { SearchBar } from './components/SearchBar';
import { useTabs } from './hooks/useTabs';

export default function App() {
  const { 
    tabs, 
    activeTab, 
    isLoading, 
    addTab, 
    closeTab, 
    setActiveTab, 
    navigateTab,
    goBack,
    goForward,
    reload,
    canGoBack,
    canGoForward
  } = useTabs();
  
  const currentTab = tabs.find(tab => tab.id === activeTab);

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      <SearchAnimation isVisible={isLoading} />
      <TabBar 
        tabs={tabs}
        activeTab={activeTab}
        onTabClose={closeTab}
        onTabSelect={setActiveTab}
      />
      <NavigationBar 
        onNewTab={addTab} 
        url={currentTab?.url || ''} 
        onNavigate={(url) => navigateTab(activeTab, url)}
        onBack={() => goBack(activeTab)}
        onForward={() => goForward(activeTab)}
        onReload={() => reload(activeTab)}
        canGoBack={canGoBack(activeTab)}
        canGoForward={canGoForward(activeTab)}
      />
      <div className="flex-1 relative">
        <MainContent tab={currentTab} />
        <SearchBar onSearch={(url) => navigateTab(activeTab, url)} />
      </div>
    </div>
  );
}